
# SWFObject

使用 SWFObject, 可用来轻松插入 Flash 内容，并对其进行操作。

---


## 模块依赖

 - [seajs](seajs/README.md)


## 使用说明

官方文档：<http://code.google.com/p/swfobject/wiki/documentation>


## 更新

当有新版本发布，需要更新时，请运行：

```
$ cd arale/dist
$ spm install swfobject
```


## 相关链接

 - https://github.com/swfobject/swfobject
