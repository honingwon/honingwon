
# Moment.js

一个轻量级的小类库，可用来对日期进行解析、格式化等操作。

---


## 模块依赖

 - [seajs](seajs/README.md)


## 使用说明

请参考漂亮的官方文档：<http://momentjs.com/docs/>


## 更新

当 Moment.js 发布新版本，需要更新时，只要运行：

```
$ cd arale/dist
$ spm install moment
```
