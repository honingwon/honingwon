<?php
header("Content-Type:text/html");
echo $_GET["callback"]
?>('\
      <div class="city-choose">\
          <span class="label">选择你所在的城市</span>\
          <span>首字母查询: </span>\
          <ul class="city-initials">\
              <li><a href="#">全部</a></li>\
                              <li><a href="#">B</a></li>\
                                 <li><a href="#">C</a></li>\
                                 <li><a href="#">H</a></li>\
                                 <li><a href="#">N</a></li>\
                                 <li><a href="#">S</a></li>\
                                 <li><a href="#">W</a></li>\
                                 <li><a href="#">X</a></li>\
                             </ul>\
      </div>\
      <ul class="pop-city-cont clearfix">\
          <li data-Initial="Q"><a href="http://ju.daily.taobao.net/tg/home.htm">全国</a></li>\
                      <li data-Initial="C"><a href="http://ju.daily.taobao.net/chengdu">成都</a></li>\
                      <li data-Initial="W"><a href="http://ju.daily.taobao.net/wuhan">武汉</a></li>\
                      <li data-Initial="N"><a href="http://ju.daily.taobao.net/nanjing">南京</a></li>\
                      <li data-Initial="S"><a href="http://ju.daily.taobao.net/shanghai">上海</a></li>\
                      <li data-Initial="W"><a href="http://ju.daily.taobao.net/wuxi">无锡</a></li>\
                      <li data-Initial="C"><a href="http://ju.daily.taobao.net/changzhou">常州</a></li>\
                      <li data-Initial="X"><a href="http://ju.daily.taobao.net/xian">西安</a></li>\
                      <li data-Initial="B"><a href="http://ju.daily.taobao.net/beijing">北京</a></li>\
                      <li data-Initial="S"><a href="http://ju.daily.taobao.net/shenzhen">深圳</a></li>\
                      <li data-Initial="S"><a href="http://ju.daily.taobao.net/suzhou">苏州</a></li>\
                      <li data-Initial="W"><a href="http://ju.daily.taobao.net/wulumuqi">乌鲁木齐</a></li>\
                      <li data-Initial="H"><a href="http://ju.daily.taobao.net/hangzhou">杭州</a></li>\
                      <li data-Initial="N"><a href="http://ju.daily.taobao.net/ningbo">宁波</a></li>\
                  </ul>\
 ')
 
