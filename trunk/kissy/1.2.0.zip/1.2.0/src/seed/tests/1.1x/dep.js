KISSY.add("1.1x-dep",function(S){
   S.Dep=1;
});