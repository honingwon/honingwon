if (!window.scriptTest2) {
    window.scriptTest2 = 1;
} else {
    window.scriptTest2++;
}