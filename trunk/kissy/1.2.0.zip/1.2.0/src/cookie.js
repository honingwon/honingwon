KISSY.add("cookie", function(S,C) {
    return C;
}, {
    requires:["cookie/base"]
});