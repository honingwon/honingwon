
# Underscore

Underscore 是一个小巧的 JavaScript 语言增强库，提供了 Collection, Array, Function,
Object 等便捷、强大的操作方法。可以与 jQuery, Backbone 等组件取长补短、一起协作使用。

---


## 模块依赖

 - [seajs](seajs/README.md)


## 使用说明

请访问淡雅的官方文档：<http://documentcloud.github.com/underscore/>


## 更新

当 Underscore 发布新版本，需要更新时，只要运行：

```
$ cd arale/dist
$ spm install underscore
```
