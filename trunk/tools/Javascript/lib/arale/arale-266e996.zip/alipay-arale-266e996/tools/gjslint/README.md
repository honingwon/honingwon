
# gjslint

由 Google 出品。

---


## 使用说明


### 安装

    python setup.py install


### 使用

    gjslint a.js
    
    // 有些风格问题可以通过以下命令解决：
    fixjsstyle a.js
