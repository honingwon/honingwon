/**
 *  KISSY Resizable
 *  @author yiminghe@gmail.com
 */
KISSY.add("resizable", function(S, R) {
    return R;
}, {
    requires:["resizable/base"]
});