<?php
header('Content-Type: text/xml; charset=utf-8');
echo '{"x":1}';
?>
