
 - 与 SeaJS 打通，通过 getActiveModule 获取所在的模块信息
