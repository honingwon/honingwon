# Calendar

日历控件。


## 模块依赖

+ seajs
+ jquery
+ overlay
+ events
+ moment

## 使用说明

```
define(function(require){
    var Calendar = require('calendar');
    var cal = Calendar();
})
```