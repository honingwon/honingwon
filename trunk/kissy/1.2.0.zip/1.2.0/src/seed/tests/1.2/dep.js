KISSY.add("1.2/dep",function(){
    return 1;
});