KISSY.add(function () {
    return 9;
});