
# Store

一个轻量级的本地存储工具，支持所有主流浏览器。

---


## 模块依赖

 - [seajs](seajs/README.md)


## 使用说明

官方文档：<https://github.com/marcuswestin/store.js#readme>


## 更新

当有新版本发布，需要更新时，请运行：

```
$ cd arale/dist
$ spm install store
```


## 相关链接

 - http://diveintohtml5.info/storage.html
 - https://github.com/andris9/jStorage
 - https://developer.mozilla.org/en/DOM/Storage
 - https://github.com/alipay/arale/issues/43
