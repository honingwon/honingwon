KISSY.add("b",function(){

},{
    requires:["./c"]
});