KISSY.add("1.2/mod", function(S, D) {
    return D + 1;
}, {
    requires:["./dep","./mod.css"]
});