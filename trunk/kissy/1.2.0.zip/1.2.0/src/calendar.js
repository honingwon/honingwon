KISSY.add("calendar", function (S, C, Page, Time, Date) {
    S.Calendar = C;
    S.Date = Date;
    C.Date = Date;
    return C;
}, {
    requires:["calendar/base", "calendar/page", "calendar/time", "calendar/date"]
});