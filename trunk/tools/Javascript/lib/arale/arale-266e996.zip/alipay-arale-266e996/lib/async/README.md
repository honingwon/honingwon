
# Async.js

Async 是一个很棒的简化 JavaScript 异步编程的工具类。它不仅能在 node 端使用，也能在浏览器端使用。

---


## 模块依赖

 - [seajs](seajs/README.md)


## 使用说明

官方文档：<https://github.com/caolan/async#readme>


## 更新

当有新版本发布，需要更新时，请运行：

```
$ cd arale/dist
$ spm install async
```
