KISSY.add("1.2/mod", function(S, D) {
    return 999;
});