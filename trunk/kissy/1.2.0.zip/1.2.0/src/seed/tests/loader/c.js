KISSY.add("c",function(){

},{
    requires:["./a"]
});