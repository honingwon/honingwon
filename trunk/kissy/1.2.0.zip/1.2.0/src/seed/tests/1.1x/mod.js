KISSY.add("1.1x-mod",function(S){
    S.Mod=S.Dep+1;
});