<?php
header("Content-Type:application/json;");
?>
{"x":1}