/**
 * mvc base
 * @author yiminghe@gmail.com
 */
KISSY.add("mvc/base", function(S, sync) {
    return {
        sync:sync
    };
}, {
    requires:['./sync']
});