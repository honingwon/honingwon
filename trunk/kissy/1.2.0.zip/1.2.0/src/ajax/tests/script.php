<?php
header("Content-Type:text/javascript;");
?>
alert("script loaded");