if (!window.t2) {
    window.t2 = 1;
} else {
    alert('bug externally');
}