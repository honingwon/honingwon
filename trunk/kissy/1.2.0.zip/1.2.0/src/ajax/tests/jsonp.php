<?php
header("Content-Type:text/javascript;");
echo $_GET["callback"]
?>
({"x":1});