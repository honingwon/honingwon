
# SeaJS

SeaJS 是一个适用于浏览器端的模块加载器。通过 SeaJS，可以简化模块加载、依赖分析和开发调试等工作。

SeaJS 的设计目的是：改变你组织 JavaScript 代码的方式。

---


## 使用说明

请访问质朴的 SeaJS 官方文档：http://seajs.org/


## 更新

当 SeaJS 发布新版本，需要更新时，只要运行：

```
$ cd arale/dist
$ spm install seajs
```
