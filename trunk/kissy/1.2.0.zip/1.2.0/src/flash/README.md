  KISSY  Flash
=================

  About
--------
这是个基于 KISSY 的管理页面 Flash 的类库。

  Request
----------
 * [KISSY](https://github.com/kissyteam/kissy)
 * [KISSY JSON package](https://github.com/kissyteam/kissy/tree/master/build/json)


  Reference
------------
 * API 文档：<http://kissyteam.github.com/kissy/docs/flash/index.html>
 * 最佳实践及参考：<http://kissyteam.github.com/kissy/docs/flash/practice/index.html>
 * 更新日志：CHANGELOG.md



