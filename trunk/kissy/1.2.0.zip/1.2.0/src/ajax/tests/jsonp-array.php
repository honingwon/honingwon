<?php
header("Content-Type:text/javascript;");
echo $_GET["callback"]
?>
(1,2);