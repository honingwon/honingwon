KISSY.add("a",function(){

},{
    requires:["./b"]
});