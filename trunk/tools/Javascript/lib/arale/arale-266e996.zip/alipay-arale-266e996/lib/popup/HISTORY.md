
# Popup

### 0.9.4 2012-06-16
    * Triggerable 改名为 Popup

### 0.9.3 2012-06-05
    * 调整为 Triggerable 继承体系


### 0.9.1 2012-05-29
    * 按照新版 Widget 以及 Base 进行改造
    * 改成了继承 Overlay 的方式
    * 支持 Delay 参数


### 0.9.0 2012-05-24
    * 包含 Dropdown 基本功能
