define(function(require, exports) {

  exports.sayHello = function() {
    document.getElementById('out').innerHTML = 'Hello, Modular World!';
  };

});
